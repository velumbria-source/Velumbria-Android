# Velumbria Android v17 — guía desde celular

Este paquete contiene el proyecto fuente Android. **No es un APK ya compilado.** Incluye un flujo de GitHub Actions para compilarlo en la nube sin computadora.

## Qué incluye
- Interfaz web de Velumbria dentro de una aplicación Android.
- OCR existente de la página (PaddleOCR/Tesseract según el flujo original).
- Traducción de texto por Google ML Kit Translation en el dispositivo.
- No usa catálogo ni API key de Google Cloud.

## Compilar usando solamente Android

1. En Chrome abre https://github.com/ e inicia sesión o crea una cuenta gratuita.
2. Pulsa **+** y crea un repositorio nuevo, por ejemplo `Velumbria-Android`. Puedes dejarlo privado.
3. En el repositorio, usa **Add file → Upload files**.
4. Descomprime este ZIP en el teléfono con Files/Archivos o ZArchiver. Sube el CONTENIDO de la carpeta `Velumbria_Android_v17` al repositorio, incluyendo la carpeta oculta `.github` y su archivo `workflows/build-apk.yml`. Si el selector no muestra archivos ocultos, crea primero las carpetas `.github/workflows` desde GitHub y añade `build-apk.yml` usando **Add file → Create new file**; pega el contenido del archivo del ZIP.
5. Confirma con **Commit changes** en la rama `main`.
6. Abre la pestaña **Actions** del repositorio. Selecciona **Construir APK de Velumbria** y pulsa **Run workflow** si no comenzó automáticamente.
7. Espera a que termine el trabajo con marca verde. Abre la ejecución y baja hasta **Artifacts**.
8. Descarga `Velumbria-Android-v17-debug`, descomprime el ZIP descargado y abre `app-debug.apk`.
9. Android puede pedir permiso para instalar aplicaciones desde Chrome/Archivos. Actívalo solo para esa aplicación y continúa si reconoces el archivo que acabas de generar.

## Traducción sin conexión
La primera vez, la traducción necesita descargar el modelo de idioma con Wi-Fi. ML Kit puede requerir descargar modelos por separado. El modelo descargado permite traducir sin conexión posteriormente. El rendimiento y la calidad pueden variar según idioma y texto.

## Importante
- GitHub Actions ofrece cuotas de minutos para repositorios privados y condiciones distintas según el plan; un repositorio público suele ser la vía más sencilla para usar Actions sin cargos de minutos, sujeto a las políticas vigentes de GitHub.
- No compartas contraseñas ni tokens de GitHub.
- Este APK será una compilación de depuración (debug), no una versión firmada para Play Store.
- Antes de usarlo con imágenes importantes, prueba OCR, selector de imágenes y descarga de modelos.
