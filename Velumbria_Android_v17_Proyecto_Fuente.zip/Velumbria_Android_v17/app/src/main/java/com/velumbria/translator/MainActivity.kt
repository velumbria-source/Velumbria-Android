package com.velumbria.translator

import android.annotation.SuppressLint
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.webkit.WebViewAssetLoader
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.ConcurrentHashMap

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private val translators = ConcurrentHashMap<String, Translator>()
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        filePathCallback?.onReceiveValue(uris.toTypedArray())
        filePathCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.settings.mediaPlaybackRequiresUserGesture = true
        webView.addJavascriptInterface(NativeBridge(), "VelumbriaNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = callback
                imagePicker.launch("image/*")
                return true
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun languageCode(code: String): String = when (code.lowercase()) {
        "ko", "kor", "kor_hang" -> TranslateLanguage.KOREAN
        "en", "eng", "eng_latn" -> TranslateLanguage.ENGLISH
        else -> TranslateLanguage.CHINESE
    }

    private fun getTranslator(source: String): Translator {
        val sourceCode = languageCode(source)
        return translators.getOrPut(sourceCode) {
            val options = TranslatorOptions.Builder()
                .setSourceLanguage(sourceCode)
                .setTargetLanguage(TranslateLanguage.SPANISH)
                .build()
            Translation.getClient(options)
        }
    }

    private fun conditions() = DownloadConditions.Builder().requireWifi().build()

    private fun jsResult(id: String, success: Boolean, message: String) {
        val safeId = org.json.JSONObject.quote(id)
        val safeMessage = org.json.JSONObject.quote(message)
        runOnUiThread {
            if (::webView.isInitialized) {
                webView.evaluateJavascript("window.onVelumbriaNativeResult($safeId,$success,$safeMessage);", null)
            }
        }
    }

    inner class NativeBridge {
        @JavascriptInterface
        fun prepareModels(source: String, requestId: String) {
            try {
                getTranslator(source).downloadModelIfNeeded(conditions())
                    .addOnSuccessListener { jsResult(requestId, true, "Modelo descargado y listo.") }
                    .addOnFailureListener { e -> jsResult(requestId, false, e.localizedMessage ?: "No se pudo descargar el modelo.") }
            } catch (e: Exception) {
                jsResult(requestId, false, e.localizedMessage ?: "Error al preparar el modelo.")
            }
        }

        @JavascriptInterface
        fun translateText(text: String, source: String, requestId: String) {
            try {
                val translator = getTranslator(source)
                translator.downloadModelIfNeeded(conditions())
                    .continueWithTask { translator.translate(text) }
                    .addOnSuccessListener { result -> jsResult(requestId, true, result) }
                    .addOnFailureListener { e -> jsResult(requestId, false, e.localizedMessage ?: "Falló la traducción.") }
            } catch (e: Exception) {
                jsResult(requestId, false, e.localizedMessage ?: "Error de traducción.")
            }
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        translators.values.forEach { it.close() }
        translators.clear()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
