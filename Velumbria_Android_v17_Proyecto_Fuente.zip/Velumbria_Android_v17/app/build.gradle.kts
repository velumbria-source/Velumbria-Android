plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.velumbria.translator"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.velumbria.translator"
        minSdk = 23
        targetSdk = 35
        versionCode = 17
        versionName = "17.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
    implementation("androidx.webkit:webkit:1.13.0")
    implementation("com.google.mlkit:translate:17.0.3")
}
